# pynq-z1_board_files

PYNQ-Z1 board files for Vivado

Copy folder to : 

{Vivado install directory}\data\boards\board_files

Working with Vivado 2016.1

